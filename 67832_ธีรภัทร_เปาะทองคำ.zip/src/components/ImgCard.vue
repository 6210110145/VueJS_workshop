<template>
  <div>
    <v-row>
        <v-col col="3">
            <v-card width="350">
                <v-img src="https://static.independent.co.uk/2021/05/24/20/doge.jpg"
                width="350"
                height="300"/>
                <v-card-title primary-title> Doge </v-card-title>
                <v-card-subtitle> This is a shiba</v-card-subtitle>
            </v-card>
        </v-col>

        <v-col col="3">
            <v-card width="350">
                <v-img src="../assets/dogecoin.jpeg.webp"
                width="350"
                height="300"/>
                <v-card-title primary-title> Cool Doge </v-card-title>
            </v-card>
        </v-col>
    </v-row>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>