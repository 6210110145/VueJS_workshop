<template>
  <!-- <shop-header /> -->
  <hello-world />
  
</template>

<script>
// import ShopHeader from '@/components/ShopHeader.vue'
  import HelloWorld from '../components/HelloWorld'

  export default {
    name: 'Home',

    components: {
      HelloWorld,
      // ShopHeader
    },
  }
</script>
